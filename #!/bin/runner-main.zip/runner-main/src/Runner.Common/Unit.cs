﻿// Represents absence of value.
namespace GitHub.Runner.Common
{
    public readonly struct Unit
    {
        public static readonly Unit Value = default;
    }
}
