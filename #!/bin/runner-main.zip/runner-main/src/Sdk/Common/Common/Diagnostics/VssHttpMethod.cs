﻿
namespace GitHub.Services.Common.Diagnostics
{
    internal enum VssHttpMethod
    {
        UNKNOWN,
        DELETE,
        HEAD,
        GET,
        OPTIONS,
        PATCH,
        POST,
        PUT,
    }
}
