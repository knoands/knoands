﻿namespace GitHub.DistributedTask.Expressions2.Tokens
{
    internal enum Associativity
    {
        None,
        LeftToRight,
        RightToLeft,
    }
}
