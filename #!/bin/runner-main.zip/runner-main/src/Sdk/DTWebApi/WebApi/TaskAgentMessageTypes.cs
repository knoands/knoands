﻿using System;
using System.Runtime.Serialization;

namespace GitHub.DistributedTask.WebApi
{
    public sealed class TaskAgentMessageTypes
    {
        public static readonly string ForceTokenRefresh = "ForceTokenRefresh";
    }
}
