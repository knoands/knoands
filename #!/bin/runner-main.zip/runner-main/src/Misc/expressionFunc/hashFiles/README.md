To compile this package (output will be stored in `Misc/layoutbin`) run `npm install && npm run prepare && npm run all`.

When you commit changes to the JSON or Typescript file, the javascript binary will be automatically re-compiled and added to the latest commit.
